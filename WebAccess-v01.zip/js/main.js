var ComponentsXML;
var newid=1;
var objectsX= new Array();
var isDragging=false;
var CurrentActive=null;

var MaxComponents = -1;

var ComponentsXMLArray= new Array();

//------------------------------------------------------------------------------------------------------------------
function loadCssFile(pathToFile) {
	var css = jQuery("<link>");
	css.attr({
		rel:  "stylesheet",
		type: "text/css",
		href: pathToFile
	});
	$("head").append(css);
}


//------------------------------------------------------------------------------------------------------------------
function SelectionBorder(element,ShowBorder)
{
	if ((ShowBorder) && (CurrentActive!=element)) {

		if (CurrentActive!=null)
		{
			$("#selectionborder").hide();
		}

		var ScTop = $("#designscroller").scrollTop();
		var ScLeft = $("#designscroller").scrollLeft();

		var x1 = ScLeft + element.position().left - 2;
		var x2 = element.outerWidth()-2;
		var y1 = ScTop  + element.position().top - 2;
		var y2 = element.outerHeight()-2;

		$("#selectionborder").css('z-index', parseInt($(element).css('z-index'),10));

		$("#selectionborder").css({'left': x1+'px' , 'top': y1+'px' , 'width': x2+'px' , 'height': y2+'px' });
		$("#selectionborder").css('border', '3px solid');
		$("#selectionborder").css('border-radius', '6px');
		$("#selectionborder").css({"-webkit-animation": "pulsate 2s ease-in-out", "-webkit-animation-iteration-count" : "infinite" });

		$("#selectionborder").fadeIn('slow');
//				$("#designspace").contextMenu(true);

		CurrentActive = element;

	} else
	{
		CurrentActive = null;
		$("#selectionborder").hide();
//				$("#designspace").contextMenu(false);

	}
}


//------------------------------------------------------------------------------------------------------------------
function parseComponentXML(xml)
{
	j = 0;
	$(xml).find("component").each(function() {
		j++;
		Xname = $(xml).find("name").text();
		XIcon = $(xml).find("icon").text();
		XID = $(xml).find("formID").text();
		XDesc = $(xml).find("description").text();

		XWidth = parseInt( $(xml).find("width").text() ,10);
		XHeight= parseInt( $(xml).find("height").text(), 10);

		$("#components-list").prepend('<div id="'+XID+'" style="cursor:pointer; z-index:20"  class="component-row"> \
				<img src="'+XIcon+'" style="float:left; width:53px; height:53px; margin-right:5px"><b>'+Xname+'</b><br>'+XDesc+' \
			</div>');

		$( "#"+XID ).draggable(   {	grid: [ 5,5 ], helper: function() { return $("<div style='cursor:pointer; width:"+(XWidth+2)+"px; height:"+(XHeight+2)+"px; border-radius: 6px; background:#999; opacity:0.5; border:1px solid black; z-index:200'></div>"); }, revert: 'invalid'	});

		loadCssFile("components/"+$(xml).find("cssfile").text());
		$.getScript("components/"+$(xml).find("jsfile").text(), function() { });
	});
}

//------------------------------------------------------------------------------------------------------------------
function SaveComponentXML(xml)
{
	ComponentsXMLArray[MaxComponents] = xml;
	parseComponentXML(ComponentsXMLArray[MaxComponents]);
}

//------------------------------------------------------------------------------------------------------------------
function LoadComponent(xmlfile)
{
	$.ajax({
		type: "GET",
		url: xmlfile+"?q=+090&time=" + Math.round(+new Date()/1000),
		dataType: "xml",
		success: SaveComponentXML
	});
}


//------------------------------------------------------------------------------------------------------------------
function parseComponentsXML(xml)
{
	j = 0;
	$(xml).find("component").each(function() {
		j++;
		MaxComponents++;
		LoadComponent($(this).text());
	});
}

//------------------------------------------------------------------------------------------------------------------
function SaveComponentsXML(xml)
{
	ComponentsXML = xml;
	parseComponentsXML(ComponentsXML);
}

//------------------------------------------------------------------------------------------------------------------
function LoadComponents()
{
	$.ajax({
		type: "GET",
		url: 'components.xml?q=090&time=' + Math.round(+new Date()/1000),
		dataType: "xml",
		success: SaveComponentsXML,
		error: function(jqXHR, textStatus, errorThrown) { console.log(textStatus, errorThrown); }
	});
}


$(function() {
	LoadComponents();


	$.contextMenu({
		selector: '.FormElement',
		callback: function(key, options) {
			var m = "clicked: " + key;
			console.log(m);
		},
		animation:{duration: 150, show: "fadeIn", hide: "fadeOut"},
		zIndex:1000,
		show: function(opt) {
			console.log("show menu");
		},
		items: {
			"sendback": {name: "Send Back",
				callback: function(key, options) {

					var zSelf = parseInt($(CurrentActive).css('z-index'));
					var xItem = CurrentActive;
					// find the z-index of the lowest item
					var maxZindex = 99999;
					$('#designspace').children(".FormElement").each(function(idx,itm) {
						//test
						console.log($(itm).attr("id"));

						//if ( $(itm).attr("id") != originalElement.attr("id") )

						var z = parseInt($(itm).css('z-index'));
						if(isNaN(z)) z = 0;
						if(z < maxZindex) { xItem = itm; maxZindex = z; }
					});

					// swap the z-indices with targetElem
					$(CurrentActive).css('z-index', maxZindex);
					$(xItem).css('z-index', zSelf);
				}
			},
			"moveforward": {name: "Bring Forward",
				callback: function(key, options) {

					var zSelf = parseInt($(CurrentActive).css('z-index'));
					var xItem = CurrentActive;

					// find the z-index of the top-most item
					var maxZindex = 0;
					$('#designspace').children(".FormElement").each(function(idx,itm) {
						//test
						console.log($(itm).attr("id"));

						//if ( $(itm).attr("id") != originalElement.attr("id") )

						var z = parseInt($(itm).css('z-index'));
						if(isNaN(z)) z = 0;
						if(z > maxZindex) { xItem = itm; maxZindex = z; }
					});

					// swap the z-indices with targetElem
					$(CurrentActive).css('z-index', maxZindex);
					$(xItem).css('z-index', zSelf);

				}
			},
			"sep1": "---------",

			"edit": {name: "Edit", icon: "edit" },
			"cut": {name: "Cut", icon: "cut"},
			"copy": {name: "Copy", icon: "copy"},
			"paste": {name: "Paste", icon: "paste"},
			"sep2": "---------",
			"delete": {name: "Delete", icon: "delete",
				callback: function(key, options) {
					$(CurrentActive).remove();
					SelectionBorder(null,false);
				}
			}
		}
	});



	$("#designspace").click( function() { SelectionBorder(null,false);  });

	$("#designspace").gridBuilder({
		color:          '#bbb',    // color of the primary gridlines
		secondaryColor: '#ccc', // color of the secondary gridlines
		vertical:       10,        // height of the vertical rhythm
		horizontal:     10,       // width of horizontal strokes
		gutter:         0,        // width of the gutter between strokes
	});


	$("#designspace").droppable({
		tolerance: 'fit',

		drop : function(event,ui)
		{
			var id = ui.draggable.attr('id');
			var newPosX = ui.offset.left - $(this).offset().left;
			var newPosY = ui.offset.top - $(this).offset().top;
//				console.log(id);
//				console.log(newPosX+" "+newPosY);

			if (id == "TButton")
			{
				$(ui.draggable).draggable('option','revert','invalid');
				newid++;
				$("#designspace").append($("<div></div>").TButton({id:newid,top:newPosY,left:newPosX,width:60,height:60,color:"red",text:"<center>Red Label<br>"}));
			}

		}
	});





});
